from __future__ import annotations

from typing import TYPE_CHECKING
from functools import cache

from sympy.combinatorics.permutations import Permutation
from sympy.external.gmpy import gcd, lcm, sqrt as isqrt
from sympy.matrices.dense import MutableDenseMatrix
from sympy.ntheory import sqrt_mod, nextprime, primitive_root, primefactors
from sympy.polys.domains import ZZ, QQ, FiniteField, EXRAW
from sympy.polys.matrices.domainmatrix import DomainMatrix
from sympy.polys.polyclasses import ANP
from sympy.printing.defaults import DefaultPrinting
from sympy.printing.repr import srepr
from sympy.utilities.iterables import ordered_partitions

if TYPE_CHECKING:
    from typing import Protocol, Iterable, Iterator, Sequence
    from sympy.combinatorics.perm_groups import PermutationGroup
    from sympy.core import Expr
    from sympy.polys.domains.domain import Domain, Er

    class CC(Protocol):
        """Protocol for a conjugacy class."""

        def __len__(self) -> int: ...
        def __iter__(self) -> Iterator[Permutation]: ...
        def __contains__(self, i: Permutation, /) -> bool: ...


class CharacterTable(DefaultPrinting):
    r"""
    A class for creating the character table of a finite group.

    Explanation
    ============

    The character table is a complex matrix with rows corresponding to characters
    and columns corresponding to conjugacy classes. Each entry is the value of the
    character on the conjugacy class, which is the trace of the representation matrix.

    The trivial character is always the first row of the character table.

    Examples
    ========

    The character table of a permutation group is computed by calling the
    ``character_table`` method on the group.

    >>> from sympy.combinatorics import SymmetricGroup, AlternatingGroup
    >>> M = SymmetricGroup(4).character_table()
    >>> type(M)
    <class 'sympy.combinatorics.character_table.CharacterTable'>

    Calling ``.as_matrix()`` on the character table returns a matrix.

    >>> M.as_matrix()
    Matrix([
     [1,  1,  1,  1,  1],
     [3,  1, -1,  0, -1],
     [2,  0,  2, -1,  0],
     [3, -1, -1,  0,  1],
     [1, -1,  1,  1, -1]])

    The character table builds upon DomainMatrix, from which users can access the
    the values of the characters as domain elements. The domain of a character table is
    either :ref:`ZZ` or a cyclotomic field :ref:`QQ(zeta_n)`.

    >>> M = AlternatingGroup(4).character_table()
    >>> M.as_matrix()
    Matrix([
    [1,          1,          1,  1],
    [1, -zeta3 - 1,      zeta3,  1],
    [1,      zeta3, -zeta3 - 1,  1],
    [3,          0,          0, -1]])
    >>> M._rep.domain
    QQ<zeta3>
    >>> M.zeta_order
    3

    The order of the columns matches the order of the conjugacy classes,
    which can be accessed with the method ``conjugacy_class_reps``.

    >>> M.conjugacy_class_reps() # doctest: +SKIP
    [(3), (0 3 1), (3)(0 2 1), (0 3)(1 2)]

    References
    ==========
    .. [1] Holt, D., Eick, B., O'Brien, E.
           "Handbook of Computational Group Theory"

    .. [2] https://en.wikipedia.org/wiki/Character_table

    .. [3] https://docs.gap-system.org/doc/ref/manual.pdf

    """
    _rep: DomainMatrix
    _conjugacy_class_reps: list[Permutation]

    def __init__(self, rep: DomainMatrix, conjugacy_class_reps: list[Permutation]):
        self._rep = rep
        self._conjugacy_class_reps = conjugacy_class_reps

    def conjugacy_class_reps(self) -> list[Permutation]:
        return self._conjugacy_class_reps[:]

    def as_domain_matrix(self) -> DomainMatrix:
        return self._rep.copy()

    def as_matrix(self) -> MutableDenseMatrix:
        rep = self._rep.to_sparse()
        if not rep.domain.is_ZZ:
            rep = rep.convert_to(EXRAW)
        return MutableDenseMatrix._fromrep(rep)

    def tolist(self) -> list[list[Expr]]:
        return self.as_matrix().tolist()

    @property
    def shape(self) -> tuple[int, int]:
        return self._rep.shape

    def __repr__(self):
        return srepr(self)

    @property
    def zeta_order(self) -> int:
        """
        Returns the order of the primitive root of unity of the underlying
        cyclotomic field.

        Examples
        ========

        >>> from sympy.combinatorics import AlternatingGroup
        >>> AlternatingGroup(3).character_table().zeta_order
        3
        >>> AlternatingGroup(5).character_table().zeta_order
        5

        It returns 1 if the character table is over :ref:`ZZ`.

        >>> from sympy.combinatorics import SymmetricGroup
        >>> SymmetricGroup(4).character_table().zeta_order
        1
        """
        if self._rep.domain.is_CyclotomicField:
            return self._rep.domain.zeta_order # type: ignore
        return 1

    @classmethod
    def from_perm_group(cls, G: PermutationGroup) -> CharacterTable:
        """
        Create a character table from a permutation group.

        Parameters
        ==========
        G : PermutationGroup
            The permutation group for which to create the character table.

        Returns
        ========
        CharacterTable
            The character table of the permutation group.

        Examples
        ========

        >>> from sympy.combinatorics import CharacterTable, AlternatingGroup
        >>> CharacterTable.from_perm_group(AlternatingGroup(4)).as_matrix()
        Matrix([
        [1,          1,          1,  1],
        [1, -zeta3 - 1,      zeta3,  1],
        [1,      zeta3, -zeta3 - 1,  1],
        [3,          0,          0, -1]])
        """
        if G.is_symmetric:
            return character_table_sn(G.degree)
        return dixon_character_table(G.conjugacy_classes())


def _compute_cmmatrices(
    cc: Sequence[CC], dom: Domain[Er]
) -> Iterator[DomainMatrix]:
    """
    Compute the class multiplication matrices.
    """
    n = len(cc)
    rmul = Permutation.rmul_with_af
    for ind in range(n):
        m = [[-1] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if m[i][j] != -1:
                    continue
                m[i] = [0] * n
                for g in cc[ind]:
                    for t in range(n):
                        out = next(iter(cc[t]))
                        # out = g^{-1} * h
                        h = rmul(out, g)
                        if h in cc[i]:
                            m[i][t] += 1
        yield DomainMatrix.from_list(m, dom)


def _dixon_prime(order: int, exponent: int) -> int:
    """Find a prime p so that `p > 2*sqrt(order)` and `p%exponent == 1`."""
    if exponent == 1:
        # trivial group <=> exponent == 1
        return 3

    p = int(2 * isqrt(order))
    while True:
        p = nextprime(p + 1)
        if p % exponent == 1:
            break
    return p


def _simultaneous_diagonalize(
    mats: Iterable[DomainMatrix], check_dim: bool = True
) -> DomainMatrix:
    """
    Compute the simultaneous diagonalization of a list of DomainMatrices.
    Returns Z such that `Z * N * Z.inv()` is diagonal for all N in mats
    and Z is on the same domain as mats (assuming Z exists).

    This is used internally for computing the simultaneous diagonalization
    of class multiplication matrices, where such Z must exist.
    """
    it = iter(mats)
    N0 = next(it)
    spaces = [S for _, __, S in N0.ground_eigenvects()]
    n = N0.shape[0]
    for N in it:
        if len(spaces) == n:
            break

        new_spaces = []
        for S in spaces:
            if S.shape[0] <= 1:
                new_spaces.append(S)
                continue
            _, pivots = S.rref()
            N1 = N.extract(range(S.shape[1]), pivots)
            for _, __, sub_S in (S * N1).transpose().ground_eigenvects():
                # sub_S: (sub_dim x dim), S: (dim x n) -> (sub_dim x n)
                sub_S = sub_S.transpose().rref()[0]
                new_spaces.append(sub_S * S)
        spaces = new_spaces

    if check_dim and len(spaces) != n:
        # not expected to happen here
        raise ValueError("Failed to compute the common eigenspace decomposition.")

    return DomainMatrix.vstack(*spaces)


def _get_invmap(cc: Sequence[CC]) -> list[int]:
    """Compute `inv_map[i] = j` such that `class[i]**-1 == class[j]`."""
    inv_map = [-1] * len(cc)
    reps = [next(iter(c)) for c in cc]
    inv_reps = [~g for g in reps]
    for i, ig in enumerate(inv_reps):
        if inv_map[i] != -1:
            continue
        for j, c in enumerate(cc):
            if ig in c:
                inv_map[i] = j
                inv_map[j] = i
                break
    return inv_map


def _get_powermap(cc: Sequence[CC], exponent: int) -> list[list[int]]:
    """Compute `pm[i][pow] = k` such that `class[i]**pow == class[k]`."""
    n = len(cc)
    pm = [[-1] * exponent for _ in range(n)]
    reps = [next(iter(c)) for c in cc]
    rmul = Permutation.rmul_with_af
    identity = rmul(reps[0], ~reps[0])
    for i in range(n):
        g = reps[i]
        gk = identity
        for k in range(exponent):
            for t in range(n):
                if gk in cc[t]:
                    pm[i][k] = t
                    break
            gk = rmul(gk, g)
    return pm


def _normalize_fp(cc: Sequence[CC], X: DomainMatrix, p: int) -> list[list]:
    """
    Scale the eigenvectors to match the character table.
    """
    Fp = X.domain
    n = len(cc)
    rows = X.to_list()
    cc_sizes = [Fp(len(c)) for c in cc]
    order = Fp(sum(len(cc[t]) for t in range(len(cc))))

    inv_map = _get_invmap(cc)
    normalized_rows = []
    for row in rows:
        # 1. normalize so the first class is 1
        scale = 1 / row[0]
        row = [x * scale for x in row]

        # 2. chi(1)^2 * sum |Ci| * row[i] * row[inv_i] = |G|
        dot = sum(cc_sizes[k] * row[k] * row[inv_map[k]] for k in range(n))

        # chi1_sq = |G| / dot
        chi1_sq = order / dot

        root = sqrt_mod(int(chi1_sq), p)
        if root is None:
            # not expected to happen
            raise ValueError(f"Failed to compute sqrt({chi1_sq}) on {Fp}")
        chi1 = Fp(root)

        normalized_rows.append([x * chi1 for x in row])

    return normalized_rows


def _get_global_conductor(
    rows: list[list[Er]], pm: list[list[int]], m: int
) -> int:
    """
    Find the smallest natural number k such that all values of the
    character table can be embedded in the k-th cyclotomic field.
    """
    n = len(rows)
    gal_m = [a for a in range(m) if gcd(a, m) == 1]
    p_factors = primefactors(m)[::-1]

    for p in p_factors:
        while m % p == 0:
            # test invariance under m//p
            m = m // p
            r = 1 % m

            fixed = True
            for a in gal_m:
                if a % m != r:
                    continue
                for i in range(n):
                    row = rows[i]
                    for j in range(n):
                        if row[pm[j][a]] != row[j]:
                            fixed = False
                            break
                    if not fixed:
                        break
                if not fixed:
                    break

            if not fixed:
                m = m * p  # restore
                break
    return m


def _lift_to_minimal_field(
    rows: list[list], pm: list[list[int]], k: int, e: int, Fp: FiniteField
) -> DomainMatrix:
    """
    Lift the normalized character table from Fp to the
    k-th cyclotomic field.
    """
    n = len(rows)
    p = Fp.mod
    half_p = p // 2

    if k == 1:
        # integer character table
        int_rows = []
        for i in range(n):
            # abs(every entry) <= sqrt(|G|) <= p//2
            row = [ZZ(int(v)) for v in rows[i]]
            row = [v if v <= half_p else v - p for v in row]
            int_rows.append(row)
        _sort_characters(int_rows, ZZ)
        return DomainMatrix(int_rows, (n, n), ZZ)

    dom = QQ.cyclotomic_field(k)

    x = Fp(primitive_root(p)) ** ((p - 1) // k)

    gal = [a for a in range(k) if gcd(a, k) == 1]
    phi = len(gal)

    # V[a, i] = (x**a)**i
    V = []
    for a in gal:
        xa = x**a
        row = [xa**i for i in range(phi)]
        V.append(row)

    V_mat = DomainMatrix(V, (phi, phi), Fp)
    V_inv = V_mat.inv()

    # for a in (Z/k)*, find A in (Z/exp)* that A = a (mod k)
    gal_lifted = []
    for a in gal:
        A = a
        while gcd(A, e) != 1:
            A += k
        gal_lifted.append(A)

    dM = []
    for i in range(n):
        row = rows[i]
        row_anps: list[ANP] = []

        for j in range(n):
            # [chi(g^A1), chi(g^A2), ...] mod p
            b_data = []
            for A in gal_lifted:
                b_data.append([row[pm[j][A % e]]])

            b = DomainMatrix(b_data, (phi, 1), Fp)

            # c = V^-1 * b
            c = (V_inv * b).to_list_flat()

            c = [int(v) for v in c]
            c = [v if v <= half_p else v - p for v in c]

            row_anps.append(ANP(c[::-1], dom.mod, QQ))

        dM.append(row_anps)

    _sort_characters(dM, dom)
    return DomainMatrix(dM, (n, n), dom)


def _sort_characters(rows: list[list[Er]], dom: Domain[Er]):
    """
    Sort the character table and move the trivial
    character to the first row. Done in-place.
    """
    one = dom.one
    rows.sort()
    for i in range(len(rows)):
        if all(v == one for v in rows[i]):
            rows[0], rows[i] = rows[i], rows[0]
            break


def dixon_character_table(conjugacy_classes: Sequence[set[Permutation]]) -> CharacterTable:
    """
    Compute the character table of a permutation group from its conjugacy classes
    using Dixon's algorithm.

    Parameters
    ==========
    conjugacy_classes : Sequence[set[Permutation]]
        The conjugacy classes of the group.

    Examples
    ==========

    >>> from sympy.combinatorics.character_table import dixon_character_table
    >>> from sympy.combinatorics import AlternatingGroup
    >>> G = AlternatingGroup(4)
    >>> dixon_character_table(G.conjugacy_classes()).as_matrix()
    Matrix([
    [1,          1,          1,  1],
    [1, -zeta3 - 1,      zeta3,  1],
    [1,      zeta3, -zeta3 - 1,  1],
    [3,          0,          0, -1]])

    References
    ==========
    .. [1] Dixon, J.
             "High Speed Computation of Group Characters"

    .. [2] Schneider, J.
             "Dixon's character table algorithm revisited"

    .. [3] Holt, D., Eick, B., O'Brien, E.
             "Handbook of Computational Group Theory"
    """
    cc = conjugacy_classes

    # move the identity class to the front
    for i, c in enumerate(cc):
        if next(iter(c)).is_identity:
            identity = i
            break
    else:
        raise ValueError("No identity class found")

    if identity != 0:
        cc = list(cc)
        cc[identity], cc[0] = cc[0], cc[identity]

    size = [len(c) for c in cc]
    order = sum(size)
    exponent = int(lcm(*(int(next(iter(c)).order()) for c in cc)))
    p = _dixon_prime(order, exponent)
    Fp = FiniteField(p)

    mats = _compute_cmmatrices(cc, Fp)
    X = _simultaneous_diagonalize(mats)

    rows = _normalize_fp(cc, X, p)
    pm = _get_powermap(cc, exponent)

    conductor = _get_global_conductor(rows, pm, exponent)
    dm = _lift_to_minimal_field(rows, pm, conductor, exponent, Fp)

    # restore the place of the identity class
    if identity != 0:
        _rows = list(range(dm.shape[0]))
        _cols = _rows[:]
        _cols[0], _cols[identity] = _cols[identity], _cols[0]
        dm = dm.extract(_rows, _cols)

    conjugacy_class_reps = [next(iter(c)) for c in conjugacy_classes]
    return CharacterTable(dm, conjugacy_class_reps)


def character_table_sn(n: int) -> CharacterTable:
    r"""
    Compute the character table of the symmetric group `S_n`
    using the Murnaghan-Nakayama rule.

    The rows are indexed by partitions of `n` in reverse lexicographic
    order, and the columns are indexed by partitions of `n` in
    lexicographic order. Thus, the first row is the trivial character, the
    last row is the sign character, and the first column is the identity
    conjugacy class.

    Parameters
    ==========
    n : int
        The degree of the symmetric group.

    Returns
    =======
    CharacterTable
        The character table of ``S_n``.

    Examples
    ========

    >>> from sympy.combinatorics.character_table import character_table_sn
    >>> character_table_sn(1).tolist()
    [[1]]
    >>> character_table_sn(2).tolist()
    [[1, 1], [1, -1]]
    >>> character_table_sn(3).tolist()
    [[1, 1, 1], [2, 0, -1], [1, -1, 1]]
    >>> character_table_sn(4).tolist()
    [[1, 1, 1, 1, 1], [3, 1, -1, 0, -1], [2, 0, 2, -1, 0],
     [3, -1, -1, 0, 1], [1, -1, 1, 1, -1]]

    Reference
    =========
    .. [1] https://en.wikipedia.org/wiki/Murnaghan-Nakayama_rule
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    partitions = sorted(tuple(reversed(part)) for part in ordered_partitions(n))
    row_labels = list(reversed(partitions))
    col_labels = partitions

    def beta_of(lam: tuple[int, ...]) -> tuple[int, ...]:
        return tuple(
            (lam[i] if i < len(lam) else 0) + n - 1 - i
            for i in range(n)
        )

    def beta_to_partition(beta: tuple[int, ...]) -> tuple[int, ...]:
        return tuple(
            value - (n - 1 - index)
            for index, value in enumerate(beta)
            if value > n - 1 - index
        )

    @cache
    def character(lam: tuple[int, ...], mu: tuple[int, ...]) -> int:
        if not mu:
            return int(not lam)

        beta = beta_of(lam)
        beta_set = set(beta)
        cycle_length = mu[0]
        total = 0

        for i, bead in enumerate(beta):
            # use beta numbers to find the border strips
            new_bead = bead - cycle_length
            if new_bead < 0 or new_bead in beta_set:
                continue

            height = sum(
                crossed_bead > new_bead for crossed_bead in beta[i + 1:]
            )
            new_beta = list(beta)
            del new_beta[i]
            insert_at = 0
            while insert_at < len(new_beta) and new_beta[insert_at] > new_bead:
                insert_at += 1
            new_beta.insert(insert_at, new_bead)
            new_partition = beta_to_partition(tuple(new_beta))

            # the recursive Murnaghan-Nakayama rule
            total += (-1) ** height * character(new_partition, mu[1:])

        return total

    def representative(partition: tuple[int, ...]) -> Permutation:
        array_form = list(range(n))
        start = 0
        for cycle_length in partition:
            for index in range(cycle_length):
                array_form[start + index] = start + (index + 1) % cycle_length
            start += cycle_length
        return Permutation(array_form)

    rows = [
        [character(row, column) for column in col_labels]
        for row in row_labels
    ]
    rep = DomainMatrix.from_list(rows, ZZ)
    reps = [representative(partition) for partition in col_labels]
    return CharacterTable(rep, reps)
